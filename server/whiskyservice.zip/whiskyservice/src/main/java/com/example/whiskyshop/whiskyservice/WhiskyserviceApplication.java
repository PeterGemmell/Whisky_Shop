package com.example.whiskyshop.whiskyservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WhiskyserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(WhiskyserviceApplication.class, args);
	}

}
